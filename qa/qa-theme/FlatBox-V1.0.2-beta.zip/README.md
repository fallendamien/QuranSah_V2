#FlatBox
###Version 1.0.2-beta

![alt tag](http://s26.postimg.org/4ncojgvgp/Flat_Box_Banner.jpg)

FlatBox is a responsive theme by [Q2A Market] for [Question2Answer] script. It has great look with flat color scheme and have many additional features which will helps your users to enjoy reading.

Features
========
- Responsive Layout
- Design with verrical rythem technique for easy redability
- Nice contrast for best reading experience
- Flat color scheme
- Few color options
- Custom advert places
- Social widgets in footer

> If you have any issue or query, feel free to post on our support section
> You also can create an issue on this repository

Changelog 1.0.2-beta
====================
- Fixed font issue
- Removed duplicate Twitter setting form fields
- Removed unused images
- Changed theme update link (set it with github repo)
- Changed plugin update link (set it with github repo)

Changelog 1.0.1-beta
====================

- Fixed default avatr visibility issue for use account toggle on header
- Fixed social widget account setup issue
- Fixed custom menu items icons issue. Added default icons
 - Pages icon for custom page
 - Link icon for external link
- Fixed footer link spacing issue
- Fixed search box alignment issue
- Other minor issues


[Q2A Market]: http://www.q2amarket.com
[Question2Answer]: http://www.question2answer.org
